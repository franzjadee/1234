<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPCST WEBSITE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/swiper-bundle.css') }}">

    <link rel="stylesheet" href="{{ asset('css/style.css') }}">

</head>
<body>
    
    <!-- header section -->
    <header class="header">

        <a href="#" class="logo"><i class="fas fa-book"></i> epcst</a>

        <nav class="navbar">
            <a href="#home" class="hover-underline">home</a>
            <a href="#about" class="hover-underline">about</a>
            <a href="#courses" class="hover-underline">courses</a>
            <a href="#teacher" class="hover-underline">teacher</a>
            <a href="#review" class="hover-underline">review</a>
            <a href="#blog" class="hover-underline">blog</a>
            <a href="#contact" class="hover-underline">contact</a>
        </nav>

        <div class="icons">
            <div id="login-btn" class="fas fa-user"></div>
            <div id="menu-btn" class="fas fa-bars"></div>
        </div>

        <!-- login form -->

        <form action="" class="login-form">
            <h3>login form</h3>
            <input type="email" placeholder="enter your email" class="box">
            <input type="password" placeholder="enter your password" class="box">
            <div class="remember">
                <input type="checkbox" name="" id="remember">
                <label for="remember-me">remember me</label>
            </div>
            <a href="#" class="btn">
                <span class="text text-1">login now</span>
                <span class="text text-2" aria-hidden="true">login now</span>
            </a>
        </form>

    </header>

    <!-- home section -->
    <section class="home" id="home">
    <div class="content">
        <h3>Eastwoods Professional College of Science and Technology</h3>
        <p>
        Eastwoods Professional College of Science and Technology (EPCST) in Balanga, Bataan, offers diverse academic and technical programs to equip students with skills and knowledge for successful careers.</p>
        <a href="#" class="btn">
            <span class="text text-1">learn more</span>
            <span class="text text-2" aria-hidden="true">learn more</span>
        </a>
    </div>
    <div class="image">
        <img src="images/img2.jpg" alt="Courses Image">
    </div>
</section>

    <!-- about section -->

    <section class="about" id="about">

        <h1 class="heading">about us</h1>

        <div class="container">

            <figure class="about-image">
                <img src="images/img3.jpg" alt="" height="500">
                <img src="images/img1.jpg" alt="" class="about-img">
            </figure>

            <div class="about-content">
                <h3>Eastwoods College of Science and Technology</h3>
                <p>Eastwoods Professional College of Science and Technology (EPCST), established in 1994, is committed to providing high quality technical, health, and higher education programs..</p>
                <p>Located in Balanga City, Bataan, EPCST offers a variety of degree and diploma courses aimed at ensuring employability and career success for its students. The college's mission is to develop individuals who are not only skilled but also productive and ready to make significant contributions to society.</p>    
                <a href="#" class="btn">
                    <span class="text text-1">read more</span>
                    <span class="text text-2" aria-hidden="false">read more</span>
                </a>        
            </div>

        </div>

    </section>

    <!-- subjects section -->

    <section class="subjects">

        <h1 class="heading">our popular subjects</h1>

        <div class="box-container">

            <div class="box">
                <img src="images/subject-1.png" alt="">
                <h3>development</h3>
            </div>

            <div class="box">
                <img src="images/subject-2.png" alt="">
                <h3>mathematics</h3>
            </div>

            <div class="box">
                <img src="images/subject-3.png" alt="">
                <h3>graphic designing</h3>
            </div>

            <div class="box">
                <img src="images/subject-4.png" alt="">
                <h3>engineering</h3>
            </div>

        </div>

    </section>

    <!-- courses section -->

    <section class="courses" id="courses">

        <h1 class="heading">Our Courses</h1>

        <div class="box-container">

            <!-- Course 1 -->
            <div class="box">
                <div class="image shine">
                    <img src="images/img4.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Bachelor of Science in Information Technology</h3>
                    <div class="stars">
                    </div>
                    <div class="icons">
                    </div>
                </div>
            </div>

            <!-- Course 2 -->
            <div class="box">
                <div class="image shine">
                    <img src="images/img5.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Bachelor of Science in Computer Science</h3>
                    <div class="stars">
                    </div>
                    <div class="icons">
                    </div>
                </div>
            </div>

             <!-- Course 3 -->
             <div class="box">
                <div class="image shine">
                    <img src="images/img6.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Bachelor of Science in Computer Engineering</h3>
                    <div class="stars">
                    </div>
                    <div class="icons">
                    </div>
                </div>
            </div>

            <!-- Course 4 -->
            <div class="box">
                <div class="image shine">
                    <img src="images/img7.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Bachelor of Science in Software Engineering</h3>
                    <div class="stars">
                    </div>
                    <div class="icons">
                    </div>
                </div>
            </div>

            <!-- Course 5 -->
            <div class="box">
                <div class="image shine">
                    <img src="images/img8.jpg" alt="">
                </div>
                <div class="content">
                    <h3>Bachelor of Science in Data Science </h3>
                    <div class="stars">
                    </div>
                    <div class="icons">
                    </div>
                </div>
            </div>

        </div>

    </section>


    <?php
$teachers = [
    [
        'name' => 'Jhai De Guzman',
        'position' => 'instructor',
        'image' => 'images/img9.jpg',
        'social' => [
            'facebook' => '#',
            'twitter' => '#',
            'instagram' => '#'
        ]
    ],
    [
        'name' => 'Nomer Aleviado',
        'position' => 'instructor',
        'image' => 'images/img9.jpg',
        'social' => [
            'facebook' => '#',
            'twitter' => '#',
            'instagram' => '#'
        ]
    ],
    [
        'name' => 'Jedd Salalila',
        'position' => 'instructor',
        'image' => 'images/img9.jpg',
        'social' => [
            'facebook' => '#',
            'twitter' => '#',
            'instagram' => '#'
        ]
    ],
    [
        'name' => 'Percian Borja',
        'position' => 'instructor',
        'image' => 'images/img9.jpg',
        'social' => [
            'facebook' => '#',
            'twitter' => '#',
            'instagram' => '#'
        ]
    ]
];
?>

<section class="teacher" id="teacher">

    <h1 class="heading">our expert teacher</h1>

    <div class="box-container">

        <?php foreach ($teachers as $teacher): ?>
            <div class="box">
                <div class="image">
                    <img src="<?php echo $teacher['image']; ?>" alt="">
                    <div class="share">
                        <a href="<?php echo $teacher['social']['facebook']; ?>" class="fab fa-facebook-f"></a>
                        <a href="<?php echo $teacher['social']['twitter']; ?>" class="fab fa-twitter"></a>
                        <a href="<?php echo $teacher['social']['instagram']; ?>" class="fab fa-instagram"></a>
                    </div>
                </div>
                <div class="content">
                    <h3><?php echo $teacher['name']; ?></h3>
                    <span><?php echo $teacher['position']; ?></span>
                </div>
            </div>
        <?php endforeach; ?>

    </div>

</section>


<section class="review" id="review">

<h1 class="heading">reviews</h1>

<div class="swiper review-slider">

    <div class="swiper-wrapper">

        <!-- Review Slide 1 -->
        <div class="swiper-slide slide">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            <div class="wrapper">
                <div class="separator"></div>
                <div class="separator"></div>
                <div class="separator"></div>
            </div>
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/img9.jpg" alt="">
                <div class="user-info">
                    <h3>Liam Anderson</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

             <!-- Review Slide 2 -->
             <div class="swiper-slide slide">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            <div class="wrapper">
                <div class="separator"></div>
                <div class="separator"></div>
                <div class="separator"></div>
            </div>
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/img9.jpg" alt="">
                <div class="user-info">
                    <h3>Ava Martinez</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

             <!-- Review Slide 3 -->
             <div class="swiper-slide slide">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            <div class="wrapper">
                <div class="separator"></div>
                <div class="separator"></div>
                <div class="separator"></div>
            </div>
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/img9.jpg" alt="">
                <div class="user-info">
                    <h3>Mason Carter</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

             <!-- Review Slide 4 -->
             <div class="swiper-slide slide">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            <div class="wrapper">
                <div class="separator"></div>
                <div class="separator"></div>
                <div class="separator"></div>
            </div>
            <i class="fas fa-quote-right"></i>
            <div class="user">
                <img src="images/img9.jpg" alt="">
                <div class="user-info">
                    <h3>Sophia Clark</h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>
                </div>
            </div>
        </div>

    </div>

</div>

</section>

    <!-- blog section -->

    <section class="blog" id="blog">

        <h1 class="heading">our blogs</h1>

        <div class="box-container">

            <div class="box">
                <div class="image shine">
                    <img src="images/img10.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by admin</a>
                    </div>
                    <h3>we have best courses for you</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam explicabo minus.</p>
                    <a href="#" class="btn">
                        <span class="text text-1">read more</span>
                        <span class="text text-2" aria-hidden="true">read more</span>
                    </a>
                </div>
            </div>

            <div class="box">
                <div class="image shine">
                    <img src="images/img11.jpg" alt="">
                </div>
                <div class="content">
                    <div class="icons">
                        <a href="#"><i class="fas fa-user"></i>by admin</a>
                    </div>
                    <h3>we have best courses for you</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Totam explicabo minus.</p>
                    <a href="#" class="btn">
                        <span class="text text-1">read more</span>
                        <span class="text text-2" aria-hidden="true">read more</span>
                    </a>
                </div>
            </div>

        </div>

    </section>>

    <!-- contact section -->

    <section class="contact" id="contact">

        <h1 class="heading">contact us</h1>

        <div class="row">
            <div class="image">
                <img src="images/contact.png" alt="">
            </div>
            <form action="" method="">
                <h3>send us a message</h3>
                <input type="text" name="name" placeholder="name" class="box" required>
                <input type="email" name="email" placeholder="email" class="box" required>
                <input type="number" name="phone" placeholder="phone number" class="box" required>
                <textarea name="message" placeholder="message" class="box" cols="30" rows="10" required></textarea>
                <button type="submit" class="btn">
                    <span class="text text-1">send message</span>
                    <span class="text text-2" aria-hidden="true">send message</span>
                </button>
            </form>
        </div>

    </section>

    <!-- footer section -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>official website</h3>
                <p>epcst.edu.ph</p>
                <div class="share">
                    <a href="#" class="fab fa-facebook-f"></a>
                    <a href="#" class="fab fa-twitter"></a>
                    <a href="#" class="fab fa-instagram"></a>
                    <a href="#" class="fab fa-linkedin"></a>
                </div>
            </div>

            <div class="box">
                <h3>contact us</h3>
                <p>+63 (47) 791 2791</p>
                <a href="mailto:ninjashub4@gmail.com" class="link">EastwoodsProfessional@yahoo.com</a>
            </div>

            <div class="box">
                <h3>Our Location</h3>
                <p>A.H. Banzon Street, Barangay Ibayo, Balanga City, Bataan 2100</p>
            </div>

        </div>

    </section>

    <script src="{{ asset('js/swiper-bundle.min.js') }}"></script>
    <script src="{{ asset('js/script.js') }}"></script>


</body>
</html>
